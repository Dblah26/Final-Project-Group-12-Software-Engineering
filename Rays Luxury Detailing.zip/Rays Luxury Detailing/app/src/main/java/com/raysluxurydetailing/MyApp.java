package com.raysluxurydetailing;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

import com.onesignal.OSNotificationReceivedEvent;
import com.onesignal.OneSignal;

public class MyApp extends Application {
    private static final String ONESIGNAL_APP_ID = "";

    @Override
    public void onCreate() {
        super.onCreate();

        // Enable verbose OneSignal logging to debug issues if needed.
        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        OneSignal.initWithContext(this);
        OneSignal.setAppId(ONESIGNAL_APP_ID);

        OneSignal.setNotificationOpenedHandler(result -> {
            String launchURL = result.getNotification().getLaunchURL();
            String title = result.getNotification().getTitle();
            String desc = result.getNotification().getBody();

//            Log.e("Launch", "url " + launchURL);

            if (launchURL != null) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("title", title);
                intent.putExtra("url", launchURL);
                Log.e("OSNotificationPayload", "result.notification.payload: " + launchURL);
                startActivity(intent);
            }
        });

        OneSignal.unsubscribeWhenNotificationsAreDisabled(true);

        OneSignal.setNotificationWillShowInForegroundHandler(new OneSignal.OSNotificationWillShowInForegroundHandler() {
            @Override
            public void notificationWillShowInForeground(OSNotificationReceivedEvent notificationReceivedEvent) {
                notificationReceivedEvent.complete(notificationReceivedEvent.getNotification());
            }
        });


    }


}
