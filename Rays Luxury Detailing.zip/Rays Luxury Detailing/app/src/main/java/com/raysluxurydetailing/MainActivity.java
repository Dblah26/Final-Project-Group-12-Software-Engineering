package com.raysluxurydetailing;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.RequiresApi;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import im.delight.android.webview.AdvancedWebView;

public class MainActivity extends Activity implements AdvancedWebView.Listener {

    private AdvancedWebView mWebView;
    // public ProgressBar progressBar;
    String loadUrl;


    //View ll_pView, pView;
    SwipeRefreshLayout mSwipeRefreshLayout;
    ProgressBar progressBar;


    private static final String URL = "https://www.raysluxurydetailing.com/";

    //ProgressDialog pd;
    View ivSplash, ivError;
    // ImageView ivSharing;
    private String userAgent;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    //@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // setContentView(R.layout.activity_main);
        //pd = new ProgressDialog(this, R.style.pdtheme);
//        pd.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
//        pd.setCancelable(false);
//        pd.show();

        setContentView(R.layout.activity_main);

        //OneSignal.startInit(this).init();


        try {
            Intent obj = getIntent();
            String url = obj.getStringExtra("url");
            Log.e("One Signal URL", "openURL = " + url);
            if (TextUtils.isEmpty(url)) {
                loadUrl = URL;
            } else {
                if (url.contains("http")) {
                    loadUrl = url;
                } else {
                    loadUrl = URL;
                }
            }
        } catch (Exception e) {
            Log.i("One Signal URL", "Failed to open = ");
            loadUrl = URL;
        }


        progressBar = (ProgressBar) findViewById(R.id.prg);

        //ll_pView = (View) findViewById(R.id.ll_pView);

        // pView = (View) findViewById(R.id.pView);
        //mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.activity_main_swipe_refresh_layout);
        mSwipeRefreshLayout = (SwipeRefreshLayout) this.findViewById(R.id.swipeContainer);

        ivSplash = findViewById(R.id.ivSplash);
        ivError = findViewById(R.id.ivError);
//        btnBack = (ImageView) findViewById(R.id.btnBack);
//        btnForward = (ImageView) findViewById(R.id.Forward);


        //findViewById(R.id.btnLogin).setOnClickListener(new View.OnClickListener() {
        //  @Override
        //  public void onClick(View v) {
        //     mWebView.loadUrl("https://www.mobochanic.com/work-order.html");
        //  }
        //});
//        btnhome1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mWebView.goBack();
//            }
//        });

        findViewById(R.id.btnHome).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mWebView.goBack();
            }
        });

//        findViewById(R.id.btnMarket).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mWebView.loadUrl("https://www.tchatchoulondon.com/pages/faqs");
//            }
//        });


        findViewById(R.id.btnhome1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mWebView.loadUrl("https://www.alexander-restaurant.ch/de");
            }
        });

//        findViewById(R.id.btnNEWS).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mWebView.loadUrl("https://www.tchatchoulondon.com/pages/contact-us");
//            }
//        });

        findViewById(R.id.Forward).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mWebView.goForward();
            }
        });


//        btnForward.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mWebView.goForward();
//            }
//        });
        //ivSharing = (ImageView) findViewById(R.id.ivSharing);
        //ivSharing.setOnClickListener(new View.OnClickListener() {

        //  @Override
        //  public void onClick(View arg0) {
        //    Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        //  sharingIntent.setType("text/plain");
        //  sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, mWebView.getTitle());
        //  sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, mWebView.getUrl());
        //  startActivity(Intent.createChooser(sharingIntent, "Share URL via"));
        // }
        //  });



        mWebView = (AdvancedWebView) findViewById(R.id.webView);
        mWebView.getSettings().setJavaScriptEnabled(true);
        WebSettings webSettings = mWebView.getSettings();
        mWebView.getSettings().setPluginState(WebSettings.PluginState.ON);
        mWebView.getSettings().setLoadWithOverviewMode(true);
        mWebView.getSettings().setUseWideViewPort(true);
        //mWebView.getSettings().setBuiltInZoomControls(true);
        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.getSettings().setSaveFormData(true);
        mWebView.getSettings().setAllowContentAccess(true);
        mWebView.getSettings().setAllowFileAccess(true);
        mWebView.getSettings().setAllowFileAccessFromFileURLs(true);
        mWebView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        mWebView.getSettings().setSupportZoom(true);
        mWebView.setWebViewClient(new WebViewClient());
        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mWebView.getSettings().setGeolocationEnabled(true);
        mWebView.getSettings().setAppCacheEnabled(true);
        mWebView.getSettings(). setUseWideViewPort(true);
        mWebView.getSettings().setLoadWithOverviewMode(true);
        mWebView.getSettings().setAllowFileAccess(true);
        mWebView.getSettings().setAllowContentAccess(true);
        mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mWebView.getSettings().setDatabaseEnabled(true);
//               mWebView.getSettings().setUserAgentString("Web App");
        mWebView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        mWebView.getSettings().setAppCachePath(getApplicationContext().getFilesDir().getAbsolutePath() + "/cache");
        mWebView.getSettings().setDatabaseEnabled(true);
        mWebView.getSettings().setDatabasePath(getApplicationContext().getFilesDir().getAbsolutePath() + "/databases");
        mWebView.setClickable(true);
        mWebView.getSettings().setUseWideViewPort(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setDatabaseEnabled(true);

        //webSettings.setUserAgentString("Web App");
        mWebView.setWebChromeClient(new WebChromeClient());
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        //mWebView.getSettings().setUserAgentString("raysluxurydetailing");
        mWebView.setWebChromeClient(new WebChromeClient());
        //mWebView.setWebChromeClient(new MyChrome());
//        mWebView.loadUrl("https://coolpeoplenetwork.us/?p=videos");

        mWebView.setListener(this, this);
        mWebView.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimetype,
                                        long contentLength) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);


            }
        });


        mWebView.setWebChromeClient(new WebChromeClient() {

            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            private View mCustomView;
            private CustomViewCallback mCustomViewCallback;
            protected FrameLayout mFullscreenContainer;
            private int mOriginalOrientation;
            private int mOriginalSystemUiVisibility;


            public Bitmap getDefaultVideoPoster() {
                if (mCustomView == null) {
                    return null;
                }
                return BitmapFactory.decodeResource(getApplicationContext().getResources(), 2130837573);
            }

            public void onHideCustomView() {
                ((FrameLayout) getWindow().getDecorView()).removeView(this.mCustomView);
                this.mCustomView = null;
                getWindow().getDecorView().setSystemUiVisibility(this.mOriginalSystemUiVisibility);
                setRequestedOrientation(this.mOriginalOrientation);
                this.mCustomViewCallback.onCustomViewHidden();
                this.mCustomViewCallback = null;
            }

            public void onShowCustomView(View paramView, CustomViewCallback paramCustomViewCallback) {
                if (this.mCustomView != null) {
                    onHideCustomView();
                    return;
                }
                this.mCustomView = paramView;
                this.mOriginalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
                this.mOriginalOrientation = getRequestedOrientation();
                this.mCustomViewCallback = paramCustomViewCallback;
                ((FrameLayout) getWindow().getDecorView()).addView(this.mCustomView, new FrameLayout.LayoutParams(-1, -1));
                getWindow().getDecorView().setSystemUiVisibility(3846);
            }


            @Override
            public void onProgressChanged(WebView view, int progress) {
                // LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(pView.getLayoutParams());
                // lp.weight = progress;
                // pView.setLayoutParams(lp);

                // ll_pView.setVisibility(progress == 100 ? View.GONE : View.VISIBLE);


//                if (progress == 100)
//                    progressBar.dismiss();
//                else
//                    progressBar.show();

                checkNavigations();

            }

            //

            //mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            // @Override
            public void onRefresh() {
                mWebView.reload();
            }
        });

        this.mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(view.GONE);

//                view.loadUrl("javascript:(function() { " +
//                        "document.getElementsByClassName('btn-facebook')[0].style.display='inline-block''; })()");
//                super.onPageFinished(view, url);
//                view.loadUrl("javascript:(function() { " +
//                        "document.getElementsByClassName('btn-instagram')[0].style.display='inline-block''; })()");
//                super.onPageFinished(view, url);
//
//                view.loadUrl("javascript:(function() { " +
//                        "document.getElementsByClassName('btn-youtube')[0].style.display='inline-block''; })()");
//                super.onPageFinished(view, url);
//
//                view.loadUrl("javascript:(function() { " +
//                        "document.getElementsByClassName('account-item has-icon menu-item')[0].style.display='none'; })()");
//                super.onPageFinished(view, url);

              //  view.loadUrl("javascript:(function() { " +
                       // "document.getElementsByClassName('mainFooter')[0].style.display='none'; })()");
              //  super.onPageFinished(view, url);


                mSwipeRefreshLayout.setOnRefreshListener(
                        new SwipeRefreshLayout.OnRefreshListener() {
                            @Override
                            public void onRefresh() {
                                mWebView.reload();
                            }
                        }
                );

                //ll_pView.setVisibility(View.GONE);
                mSwipeRefreshLayout.setRefreshing(false);
                //progressBar.dismiss();
                checkNavigations();
                super.onPageFinished(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(view.VISIBLE);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.d("myTag", url);
                if (url.startsWith("tel:") || url.contains("whatsapp:") || url.startsWith("mailto:") || url.contains("facebook") || url.contains("instagram") || url.contains("youtube") ) {

                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
                    if (url != null && url.startsWith("tel:")) {

                            view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                            return true;
                    }


                    if (url != null && url.startsWith("mailto")) {
                        view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        return true;

                    }
                    if (url != null && url.contains("whatsapp")) {
                        String whatsapp = "whatsapp";
                        view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(whatsapp)));
                        return true;

                    }

                    if (url != null && url.contains("facebook")) {
                        view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        return true;

                    }
                    if (url != null && url.contains("instagram")) {
                        view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        return true;

                    }
                    if (url != null && url.contains("youtube")) {
                        view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        return true;

                    }

                    startActivity(intent);
                    view.reload();
                    return true;
                }

                view.loadUrl(url);
                return true;
            }

            //            public boolean shouldOverrideUrlLoading(WebView view, String url) {
//                // TODO Auto-generated method stub
//
//
//
//                if(url != null && url.startsWith("sms://+4917637686367") )
//                {
//                    view.getContext().startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));
//                    return true;
//
//                }else
//                if(url != null && url.startsWith("whatsapp://send/?phone=4917637686367") )
//                {
//                    view.getContext().startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));
//                    return true;
//
//                }else
//                if(url != null && url.startsWith("mailto:info@taximuneeb.de") )
//                {
//                    view.getContext().startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));
//                    return true;
//
//                }else
//                {
//                    return false;
//                }
//            }
//            ;
            //mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener()*/ {
            //@Override
            public void onRefresh() {
                mWebView.reload();
            }
        });


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    mWebView.loadUrl(loadUrl);
                    //progressBar = ProgressDialog.show(MainActivity.this, "", "Loading...");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ivSplash.setVisibility(View.GONE);
            }
        }, 3000);


        (new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    OnEverySecond();

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        })).start();
    }

    private class JavaScriptInterface {

        /**
         * this should be triggered when user and pwd is correct, maybe after
         * successful login
         */
        public void saveValues(String usr, String pwd) {

            if (usr == null || pwd == null) {
                return;
            }

            //save the values in SharedPrefs
            SharedPreferences.Editor editor = getPreferences(MODE_PRIVATE).edit();
            editor.putString("usr", usr);
            editor.putString("pwd", pwd);
            editor.apply();
        }
    }

    public boolean IsNetworkAvailable() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = cm.getActiveNetworkInfo();
            // boolean isWiFi = info.getType() == ConnectivityManager.TYPE_WIFI;
            return info != null && info.getState() == NetworkInfo.State.CONNECTED;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


    public void OnEverySecond() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (IsNetworkAvailable()) {
                    ivError.setVisibility(View.GONE);
                } else {
                    ivError.setVisibility(View.VISIBLE);
                }
            }
        });
    }


    public void handleURL(String url) {
        if (url.startsWith("tel:") || url.startsWith("geo:") || url.startsWith("mailto:")) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);

            return;
        } else
            mWebView.loadUrl(url);
        checkNavigations();
    }

    private void checkNavigations() {
        //btnBack.setVisibility(mWebView.canGoBack() ? View.VISIBLE : View.GONE);
        //btnForward.setVisibility(mWebView.canGoForward() ? View.VISIBLE : View.GONE);
    }

    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
            // other 'case' lines to check for other
            // permissions this app might request
        }
    }


    public boolean checkLocationPermission() {
        String permission = "android.permission.ACCESS_FINE_LOCATION";
        int res = this.checkCallingOrSelfPermission(permission);
        return (res == PackageManager.PERMISSION_GRANTED);
    }


    @SuppressLint("NewApi")
    @Override
    protected void onResume() {
        super.onResume();
        mWebView.onResume();
        // ...
    }

    @SuppressLint("NewApi")
    @Override
    protected void onPause() {
        mWebView.onPause();
        // ...
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        mWebView.onDestroy();
        // ...
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        mWebView.onActivityResult(requestCode, resultCode, intent);
        // ...
    }

    @Override
    public void onPageStarted(String url, Bitmap favicon) {
    }

    @Override
    public void onPageFinished(String url) {

    }

    @Override
    public void onPageError(int errorCode, String description, String failingUrl) {
    }

    @Override
    public void onDownloadRequested(String url, String suggestedFilename, String mimeType, long contentLength, String contentDisposition, String userAgent) {
    }

    @Override
    public void onExternalPageRequest(String url) {
    }

    @Override
    public void onBackPressed() {
        if (mWebView.canGoBack()) {
            mWebView.goBack();
        } else {
            super.onBackPressed();


        }
    }


}



